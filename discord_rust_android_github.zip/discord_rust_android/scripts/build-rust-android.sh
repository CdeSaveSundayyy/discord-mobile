#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../rust-core"
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 \
  -o ../app/src/main/jniLibs build --release
echo "Rust Android libraries built in app/src/main/jniLibs"
