use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use serde::Deserialize;

#[derive(Debug, Deserialize)]
struct DiscordUser {
    username: String,
    global_name: Option<String>,
    id: String,
    bot: Option<bool>,
}

fn java_string<'local>(env: &mut JNIEnv<'local>, value: String) -> jstring {
    match env.new_string(value) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_dev_example_discordrust_RustCore_version(
    mut env: JNIEnv,
    _class: JClass,
) -> jstring {
    java_string(&mut env, format!("discord_core {}", env!("CARGO_PKG_VERSION")))
}

#[no_mangle]
pub extern "system" fn Java_dev_example_discordrust_RustCore_parseCurrentUser(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jstring {
    let raw: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return java_string(&mut env, "Invalid response from Android".to_string()),
    };

    let result = match serde_json::from_str::<DiscordUser>(&raw) {
        Ok(user) => {
            let display = user.global_name.unwrap_or(user.username);
            let kind = if user.bot.unwrap_or(false) { "bot" } else { "user" };
            format!("{display} · {kind} · ID {}", user.id)
        }
        Err(_) => "Discord returned an unexpected user response".to_string(),
    };
    java_string(&mut env, result)
}
