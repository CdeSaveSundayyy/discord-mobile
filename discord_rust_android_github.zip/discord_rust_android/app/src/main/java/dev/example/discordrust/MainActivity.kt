package dev.example.discordrust

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiscordRustApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiscordRustApp() {
    var token by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Enter a Discord bot token to verify the bot.") }
    var botName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Discord · Rust client") })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Bot connection", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "This prototype connects using Discord's supported bot API. " +
                        "It does not sign in to a personal Discord account.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Bot token") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            botName = ""
                            status = try {
                                val body = withContext(Dispatchers.IO) {
                                    DiscordApi.verifyBot(token.trim())
                                }
                                val parsed = RustCore.parseCurrentUser(body)
                                botName = parsed
                                "Token verified successfully."
                            } catch (e: Exception) {
                                "Could not verify bot: ${e.message ?: "unknown error"}"
                            }
                            busy = false
                        }
                    },
                    enabled = token.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (busy) CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    ) else Text("Verify bot")
                }
                if (botName.isNotBlank()) {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Connected bot", style = MaterialTheme.typography.labelLarge)
                            Text(botName, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Rust core: ${RustCore.version()}")
                Text(
                    "Security: the token is held in memory only and is not saved by this starter. " +
                        "Use a test bot and reset its token immediately if it is exposed.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private object DiscordApi {
    private val client = OkHttpClient()

    fun verifyBot(token: String): String {
        require(token.isNotBlank()) { "Bot token is empty." }
        val request = Request.Builder()
            .url("https://discord.com/api/v10/users/@me")
            .header("Authorization", "Bot $token")
            .header("User-Agent", "DiscordRustAndroid/0.1")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val safeMessage = when (response.code) {
                    401 -> "Discord rejected the token (401). Check that this is a bot token."
                    403 -> "Discord denied this request (403)."
                    429 -> "Discord rate limited the request. Try again later."
                    else -> "Discord returned HTTP ${response.code}."
                }
                throw IOException(safeMessage)
            }
            return body
        }
    }
}
