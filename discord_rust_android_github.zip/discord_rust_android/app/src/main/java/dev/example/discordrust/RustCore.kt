package dev.example.discordrust

/**
 * JNI bridge to the Rust parsing core.
 * Build rust-core and copy the generated .so files into app/src/main/jniLibs.
 */
object RustCore {
    init {
        System.loadLibrary("discord_core")
    }

    external fun version(): String
    external fun parseCurrentUser(json: String): String
}
